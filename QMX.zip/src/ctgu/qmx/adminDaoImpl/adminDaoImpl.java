package ctgu.qmx.adminDaoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import ctgu.qmx.Jdbc.Jdbc;
import ctgu.qmx.adminDao.adminDao;
import ctgu.qmx.adminEntity.adminEntity;
import ctgu.qmx.studentEntity.studentEntity;

/**
*@autor:hwj
*
*/
public class adminDaoImpl implements adminDao {
	
	static PreparedStatement pst;
	
	public boolean adminLogin(adminEntity adminEntity) throws SQLException {
		boolean check_msg = false;
		Jdbc jdbc = new Jdbc();
		Connection connection = jdbc.getConnection();
		String sql = "select * from qmx_admin where username=?";
		try {
			pst = connection.prepareStatement(sql);
			pst.setString(1, adminEntity.getUsername());
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				sql = "select password from qmx_admin where username=?";
				pst = connection.prepareStatement(sql);
				pst.setString(1, adminEntity.getUsername());
				rs = pst.executeQuery();
				while(rs.next()) {
					if (adminEntity.getPassword().equals(rs.getString(1))) {
						check_msg = true;
					} else {
						check_msg = false;
					}
				}
			} else {
				check_msg = false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		connection.close();
		return check_msg;
	}
	
	
	
//	public static void main(String[] args) {
//		adminDaoImpl adminDaoImpl = new adminDaoImpl();
//		adminEntity adminEntity = new adminEntity();
//		adminEntity.setUsername("shakun");
//		adminEntity.setPassword("234");
//		boolean ss = adminDaoImpl.adminLogin(adminEntity);
//		System.out.println(ss);
//	}

}
