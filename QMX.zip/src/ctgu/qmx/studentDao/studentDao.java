package ctgu.qmx.studentDao;

import java.util.List;

import ctgu.qmx.studentEntity.studentEntity;

/**
*@autor:hwj
*
*/
public interface studentDao {
	
	public static void addStudent(studentEntity studentEntity) {};
	
	public static void deleteStudent(String xuehao) {};
	
	public static void updateStudent(studentEntity studentEntity) {};
	
	public static boolean search(String xuehao) {
		return false;
	};
	
	public static studentEntity geEntity(String xuehao) {
		return null;
	}
	
	public static int getTotalKF() {
		return 0;
	};
	
	public static int getTotalYJ() {
		return 0;
	};
}
