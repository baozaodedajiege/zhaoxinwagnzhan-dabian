package ctgu.qmx.adminService;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import ctgu.qmx.adminDaoImpl.adminDaoImpl;
import ctgu.qmx.adminEntity.adminEntity;
import ctgu.qmx.studentDaoImpl.studentDaoImpl;
import ctgu.qmx.studentEntity.studentEntity;

/**
*@autor:hwj
*
*/
public class adminService {
	
	public boolean doadminLogin(adminEntity adminEntity) {
		boolean ss = false;
		adminDaoImpl adminDaoImpl = new adminDaoImpl();
		try {
			ss = adminDaoImpl.adminLogin(adminEntity);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ss;
	}
	
	public void doDeleteStudent(String xuehao) {
		studentDaoImpl studentDaoImpl = new studentDaoImpl();
		try {
			studentDaoImpl.deleteStudent(xuehao);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public ResultSet doDownload(Connection connection){
		studentDaoImpl studentDaoImpl = new studentDaoImpl();
		ResultSet rs = null;
		try {
			rs = studentDaoImpl.studentList(connection);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rs;
	}
	
	public void doAddStudent(studentEntity studentEntity) {
		studentDaoImpl studentDaoImpl = new studentDaoImpl();
		try {
			studentDaoImpl.addStudent(studentEntity);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public int doGetTotalKF(){
		int ss = 0;
		studentDaoImpl studentDaoImpl = new studentDaoImpl();
		try {
			ss = studentDaoImpl.getTotalKF();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ss;
	}
	
	public int doGetTotalYJ(){
		int ss = 0;
		studentDaoImpl studentDaoImpl = new studentDaoImpl();
		try {
			ss = studentDaoImpl.getTotalYJ();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ss;
	}
	
}
