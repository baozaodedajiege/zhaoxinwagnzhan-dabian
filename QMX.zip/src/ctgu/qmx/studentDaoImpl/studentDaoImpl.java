package ctgu.qmx.studentDaoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import ctgu.qmx.Jdbc.Jdbc;
import ctgu.qmx.studentDao.studentDao;
import ctgu.qmx.studentEntity.studentEntity;

/**
*@autor:hwj
*
*/
public class studentDaoImpl implements studentDao {
	
	static PreparedStatement pst = null;
	static boolean check_msg;
	
	public void addStudent(studentEntity studentEntity) throws SQLException {
		Jdbc jdbc = new Jdbc();
		Connection connection = jdbc.getConnection();
		String sql = "insert into qmx(name,xuehao,xueyuan,zhuanye,qq,phone,sex,zubie) value(?,?,?,?,?,?,?,?)";
		pst = connection.prepareStatement(sql);
		pst.setString(1, studentEntity.getName());
		pst.setString(2, studentEntity.getXuehao());
		pst.setString(3, studentEntity.getXueyuan());
		pst.setString(4, studentEntity.getZhuanye());
		pst.setString(5, studentEntity.getQq());
		pst.setString(6, studentEntity.getPhone());
		pst.setString(7, studentEntity.getSex());
		pst.setString(8, studentEntity.getZubie());
		pst.executeUpdate();
		connection.close();
	};
	
	public boolean search(String xuehao) throws SQLException {
		Jdbc jdbc = new Jdbc();
		Connection connection = jdbc.getConnection();
		String sql = "select * from qmx where xuehao = ?";
		pst = connection.prepareStatement(sql);
		pst.setString(1, xuehao);
		ResultSet rs = pst.executeQuery();
		check_msg = rs.next();
		connection.close();
		return check_msg;
	};
	
	public static void deleteStudent(String xuehao) throws SQLException {
		Jdbc jdbc = new Jdbc();
		Connection connection = jdbc.getConnection();
		String sql = "delete from qmx where xuehao = ?";
		pst = connection.prepareStatement(sql);
		pst.setString(1, xuehao);
		pst.executeUpdate();
		connection.close();
	};
	
	public void updateStudent(studentEntity studentEntity , String xuehao) throws SQLException {
		Jdbc jdbc = new Jdbc();
		Connection connection = jdbc.getConnection();
		String sql = "update qmx set name=?,xuehao=?,xueyuan=?,zhuanye=?,qq=?,phone=?,sex=?,zubie=? "
				+ "where xuehao = ?";
		pst = connection.prepareStatement(sql);
		pst.setString(1, studentEntity.getName());
		pst.setString(2, studentEntity.getXuehao());
		pst.setString(3, studentEntity.getXueyuan());
		pst.setString(4, studentEntity.getZhuanye());
		pst.setString(5, studentEntity.getQq());
		pst.setString(6, studentEntity.getPhone());
		pst.setString(7, studentEntity.getSex());
		pst.setString(8, studentEntity.getZubie());
		pst.setString(9, xuehao);
		pst.executeUpdate();
		connection.close();
	};
	
	public studentEntity getEntity(String xuehao) throws SQLException {
		Jdbc jdbc = new Jdbc();
		Connection connection = jdbc.getConnection();
		String sql = "select* from qmx where xuehao = ?";
		pst = connection.prepareStatement(sql);
		pst.setString(1, xuehao);
		ResultSet rs = pst.executeQuery();
		studentEntity studentEntity = new studentEntity();
		while(rs.next()) {
			studentEntity.setName(rs.getString("name"));
			studentEntity.setXuehao(xuehao);
			studentEntity.setXueyuan(rs.getString("xueyuan"));
			studentEntity.setZhuanye(rs.getString("zhuanye"));
			studentEntity.setQq(rs.getString("qq"));
			studentEntity.setPhone(rs.getString("phone"));
			studentEntity.setSex(rs.getString("sex"));
			studentEntity.setZubie(rs.getString("zubie"));
		}
		connection.close();
		return studentEntity;
	}
	
	public ResultSet studentList(Connection connection) throws Exception {
        StringBuffer sb = new StringBuffer("select * from qmx");
        pst = connection.prepareStatement(sb.toString());
        return pst.executeQuery();
    }
	
	public int getTotalKF() throws SQLException {
		Jdbc jdbc = new Jdbc();
		Connection connection = jdbc.getConnection();
		String sql = "select* from qmx where zubie = '������' ";
		pst = connection.prepareStatement(sql);
		ResultSet rs = pst.executeQuery();
		int num = 0;
		while(rs.next()) {
			num++;
		}
		connection.close();
		return num;
	};
	
	public int getTotalYJ() throws SQLException {
		Jdbc jdbc = new Jdbc();
		Connection connection = jdbc.getConnection();
		String sql = "select* from qmx where zubie = 'Ӳ����' ";
		pst = connection.prepareStatement(sql);
		ResultSet rs = pst.executeQuery();
		int num = 0;
		while(rs.next()) {
			num++;
		}
		connection.close();
		return num;
	};
	
//	public static void main(String[] args) throws SQLException {
//		studentDaoImpl studentDaoImpl = new studentDaoImpl();
//		studentEntity studentEntity = new studentEntity();
//		studentEntity.setName("root3");
//		studentEntity.setPhone("root");
//		studentEntity.setQq("root");
//		studentEntity.setSex("root");
//		studentEntity.setXueyuan("root");
//		studentEntity.setXuehao("0987654321");
//		studentEntity.setZhuanye("root");
//		studentEntity.setZubie("kaifa");
//		studentDaoImpl.addStudent(studentEntity);
//		studentEntity.getName("name")
//		boolean ss = studentDaoImpl.search("20171122");
//		System.out.println(ss);
//		studentDaoImpl.deleteStudent("2017112222");
//		studentDaoImpl.changeStudent(studentEntity, "2017112233");
//		studentEntity = studentDaoImpl.getEntity("root");
//		System.out.println(studentDaoImpl.getTotalKF());
//	}
	
}
