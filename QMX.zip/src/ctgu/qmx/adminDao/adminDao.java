package ctgu.qmx.adminDao;

import ctgu.qmx.adminEntity.adminEntity;
import ctgu.qmx.studentEntity.studentEntity;

/**
*@autor:hwj
*
*/
public interface adminDao {
	
	public static boolean adminLogin(adminEntity adminEntity) {
		return false;
	};
}
