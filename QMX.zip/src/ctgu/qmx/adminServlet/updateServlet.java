package ctgu.qmx.adminServlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.cj.Session;

import ctgu.qmx.adminService.adminService;
import ctgu.qmx.studentDaoImpl.studentDaoImpl;
import ctgu.qmx.studentEntity.studentEntity;
import ctgu.qmx.studentService.studentService;

@WebServlet("/updateServlet")
public class updateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("utf-8");
		request.setCharacterEncoding("utf-8");
		String xuehao = request.getParameter("xuehao");
		HttpSession session = request.getSession();
		session.setAttribute("xuehao",xuehao);
		studentService studentService = new studentService();
		studentEntity studentEntity = null;
		try {
			studentEntity = studentService.doGetEntity(xuehao);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		request.setAttribute("studentEntity", studentEntity);
		String forward = "/welcome/correct.jsp";
		RequestDispatcher rd = request.getRequestDispatcher(forward);
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("utf-8");
		request.setCharacterEncoding("utf-8");
		
		
		HttpSession session = request.getSession();
		String xuehao = (String) session.getAttribute("xuehao");
		studentService studentService = new studentService();
		studentEntity studentEntity = new studentEntity();
		studentEntity.setName(request.getParameter("name"));
		studentEntity.setPhone(request.getParameter("phone"));
		studentEntity.setQq(request.getParameter("qq"));
		studentEntity.setSex(request.getParameter("sex"));
		studentEntity.setXuehao(request.getParameter("xuehao"));
		studentEntity.setZhuanye(request.getParameter("zhuanye"));
		studentEntity.setZubie(request.getParameter("zubie"));
		studentEntity.setXueyuan(request.getParameter("xueyuan"));
		studentService.doUpdateStudent(studentEntity,xuehao);
		adminService adminService = new adminService();
	    session.setAttribute("YJ", adminService.doGetTotalYJ());
	    session.setAttribute("KF", adminService.doGetTotalKF());
	    session.setAttribute("total", adminService.doGetTotalKF()+adminService.doGetTotalYJ());
		request.getRequestDispatcher("/WEB-INF/information.jsp").forward(request,response);
	}

}
