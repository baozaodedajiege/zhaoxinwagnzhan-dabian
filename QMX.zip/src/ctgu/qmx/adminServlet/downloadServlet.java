	package ctgu.qmx.adminServlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import ctgu.qmx.Jdbc.Jdbc;
import ctgu.qmx.adminService.adminService;
import jxl.Workbook;
import java.io.OutputStream;

@WebServlet("/downloadServlet")
public class downloadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HSSFWorkbook wb =  new HSSFWorkbook();
		String headers[] = { "����", "ѧ��", "ѧԺ", "רҵ","QQ��","��ϵ��ʽ","�Ա�","���"};// ����
        adminService adminService = new adminService();
        ResultSet rs = null;
        Jdbc jdbc = new Jdbc();
        Connection connection = jdbc.getConnection();
        rs = adminService.doDownload(connection);
        try {
			fillExcelData(rs, wb, headers);
		} catch (Exception e) {
			e.printStackTrace();
		}
        try {
			export(response, wb, "order.xls");
		} catch (Exception e) {
			e.printStackTrace();
		}
        try {
			connection.close();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	/**
     * �����û�
     * 
     * @throws Exception
     */
    public void fillExcelData(ResultSet rs, HSSFWorkbook wb, String[] headers)
            throws Exception {
        int rowIndex = 0; // ��һ��
        Sheet sheet = wb.createSheet(); // ����sheetҳ
        Row row = sheet.createRow(rowIndex++);
        // ��������
        CellStyle style =  wb.createCellStyle();
        HSSFFont font = wb.createFont();
        font.setColor((short) 0);
        font.setFontHeightInPoints((short) 14);
        font.setFontName("����");
        style.setFont(font);
        style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);   
        for (int i = 0; i < headers.length; i++) {
        	row.setHeight((short)350);
            row.createCell(i).setCellValue(headers[i]);
            row.getCell(i).setCellStyle(style); 
        }
        
        // �������ݿ��е�����
        CellStyle style1 =  wb.createCellStyle();
        HSSFFont font1 = wb.createFont();
        font1.setFontHeightInPoints((short) 14);
        font1.setFontName("����");
        style1.setFont(font1);
        while (rs.next()) {
            row = sheet.createRow(rowIndex++);
            for (int i = 0; i < headers.length; i++) {
            	row.setHeight((short)350);
            	sheet.setColumnWidth((short)i,(short)6000);
                row.createCell(i).setCellValue(rs.getObject(i + 1).toString());
                row.getCell(i).setCellStyle(style1); 
                //rs.getObject(i + 1)�õ�һ�����󣬼����ݿ���һ�еĽ����ÿһ�о������Դճ�һ�б�ɶ�����Ϊid�Ǵ�1��ʼ������Ҫ+1��
            }
        }
    }
    
    /**
     * �����ݷ��뵽.xls�ļ��в����ص�����
     * 
     * @param response
     * @param wb
     * @param fileName
     * @throws Exception
     */
    public void export(HttpServletResponse response, HSSFWorkbook wb,
            String fileName) throws Exception {
        response.setHeader("Content-Disposition", "attachment;filename="
                + new String(fileName.getBytes("utf-8"), "iso8859-1"));// ����ͷ��Ϣ
        response.setContentType("application/ynd.ms-excel;charset=UTF-8");
        OutputStream out = response.getOutputStream();
        wb.write(out);// ������������ص�����
        out.flush();
        out.close();
    }
}
