package ctgu.qmx.adminServlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ctgu.qmx.adminService.adminService;
import ctgu.qmx.studentDaoImpl.studentDaoImpl;
import ctgu.qmx.studentEntity.studentEntity;

@WebServlet("/addStudentServlet")
public class addStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
	    response.setContentType("text/html;charset=utf-8");
	    studentEntity studentEntity = new studentEntity();
		studentEntity.setName(request.getParameter("name"));
		studentEntity.setPhone(request.getParameter("phone"));
		studentEntity.setQq(request.getParameter("qq"));
		studentEntity.setSex(request.getParameter("sex"));
		studentEntity.setXuehao(request.getParameter("xuehao"));
		studentEntity.setXueyuan(request.getParameter("xueyuan"));
		studentEntity.setZubie(request.getParameter("zubie"));
		studentEntity.setZhuanye(request.getParameter("zhuanye"));
		studentDaoImpl studentDaoImpl = new studentDaoImpl();
		adminService adminService = new adminService();
		try {
			if (!studentDaoImpl.search(studentEntity.getXuehao()) && studentEntity.getXuehao()!="") {
				adminService.doAddStudent(studentEntity);
			} 
		} catch (SQLException e2) {
			e2.printStackTrace();
		}
		HttpSession session = request.getSession();
	    session.setAttribute("YJ", adminService.doGetTotalYJ());
	    session.setAttribute("KF", adminService.doGetTotalKF());
	    session.setAttribute("total", adminService.doGetTotalKF()+adminService.doGetTotalYJ());
		request.getRequestDispatcher("/WEB-INF/information.jsp").forward(request,response);
	}
}