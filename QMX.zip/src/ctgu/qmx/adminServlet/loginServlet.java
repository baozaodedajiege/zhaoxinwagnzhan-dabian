package ctgu.qmx.adminServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import ctgu.qmx.adminEntity.adminEntity;
import ctgu.qmx.adminService.adminService;

public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
	    response.setContentType("text/html;charset=utf-8");
	    adminEntity adminEntity = new adminEntity();
	    adminEntity.setUsername(request.getParameter("username"));
	    adminEntity.setPassword(request.getParameter("password"));
	    adminService adminService = new adminService();
	    HttpSession session = request.getSession();
	    session.setAttribute("YJ", adminService.doGetTotalYJ());
	    session.setAttribute("KF", adminService.doGetTotalKF());
	    session.setAttribute("total", adminService.doGetTotalKF()+adminService.doGetTotalYJ());
	    PrintWriter out=response.getWriter();
	    boolean check = adminService.doadminLogin(adminEntity);
	    if (check) {
	    	request.getRequestDispatcher("/WEB-INF/information.jsp").forward(request,response);
	    } else {
	    	out.print("<script language='javascript'>alert('�û��������������');"
	    			+ "window.location.href='welcome/login.jsp';</script>");
		}
	}

}
