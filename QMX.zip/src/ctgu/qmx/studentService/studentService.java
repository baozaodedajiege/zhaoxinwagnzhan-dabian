package ctgu.qmx.studentService;

import java.sql.SQLException;

import ctgu.qmx.studentDaoImpl.studentDaoImpl;
import ctgu.qmx.studentEntity.studentEntity;

/**
*@autor:hwj
*
*/
public class studentService {
	
	public void doAddStudent(studentEntity studentEntity) throws SQLException {
		studentDaoImpl studentDaoImpl =  new studentDaoImpl();
		studentDaoImpl.addStudent(studentEntity);
	}
	public boolean doSearchStudent(String xuehao) throws SQLException {
		studentDaoImpl studentDaoImpl = new studentDaoImpl();
		return studentDaoImpl.search(xuehao);
	}
	
	public studentEntity doGetEntity(String xuehao) throws SQLException {
		studentDaoImpl studentDaoImpl =  new studentDaoImpl();
		return studentDaoImpl.getEntity(xuehao);
	}
	
	public void doUpdateStudent(studentEntity studentEntity,String xuehao) {
		studentDaoImpl studentDaoImpl = new studentDaoImpl();
		try { 
			studentDaoImpl.updateStudent(studentEntity, xuehao);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
