package ctgu.qmx.Jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

/**
*@autor:hwj
*
*/
public class Jdbc {
	private static final String DBDriver = "com.mysql.cj.jdbc.Driver";
	private static final String DBUrl = "jdbc:mysql://localhost:3306/student?useSSL=false&serverTimezone=GMT%2B8&allowPublicKeyRetrieval=true";
	private static final String dbUser = "root";
	private static final String dbPassword = "123456";

	public Connection getConnection() {
		Connection con = null;
		try {
			Class.forName(DBDriver);
			con = DriverManager.getConnection(DBUrl, dbUser, dbPassword);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

	public void close(Connection connection) {
		try {
			if (connection != null)
				connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}