//查找
function myFunction(){
    var input,table,tr,td,i,filter;
    input = document.getElementById("a1");
    filter=input.value.toUpperCase();
    table=document.getElementById("b1");
    tr = table.getElementsByTagName("tr");
    for (var i = tr.length - 1; i > 0; i--){
        td=tr[i].getElementsByTagName("td")[1];
        if(td){
            if(td.innerHTML.toUpperCase().indexOf(filter)>-1){
                tr[i].style.display="";
            }else{
                tr[i].style.display="none";
            }
        }
    }
}

//取消查找
function cancel(){
    document.getElementById("a1").value="";
    var table,tr,td,i;
    table=document.getElementById("b1");
    tr = table.getElementsByTagName("tr");
    for (var i = tr.length - 1; i >= 0; i--){
        tr[i].style.display="";
    }
}