$(document).ready(function(){
	
	 $(function(){
		 $("#toTop").click(function(){
			 $("html").animate({"scrollTop": "0px"},500);
		     $("body").animate({"scrollTop": "0px"},500);
		 });
	 })
	
	 $('input[name="username"]').val("");
	 $('input[name="phone"]').val("");
	 $('input[name="xueyuan"]').val("");
	 $('input[name="qq"]').val("");
	 $('input[name="zhuanye"]').val("");
	 $('input[name="xuehao"]').val("");
	
	var ok1=false;
    var ok2=false;
    var ok3=false;
    var ok4=false;
    var ok5=false;
    var ok6=false;
    
 // 验证用户名不为空
    $('input[name="username"]').blur(function(){
        if($(this).val().search(/^[\u4E00-\u9FA5\uf900-\ufa2d·s]{2,20}$/)==0){
        	$("#namesId").html("");
        	ok1 = true;
        }else{
        	$("#namesId").html("请输入正确姓名格式");
        	ok1=false;
        }
    });


//验证手机号
$('input[name="phone"]').blur(function(){
     if($(this).val().search(/^1(3|4|5|7|8|9)\d{9}$/)==-1){
         $("#dianhuaId").html("请输入正确的手机格式");
         ok6 = false;
     }else{       
    	 $("#dianhuaId").html("");
    	 ok6 = true;
     }

 });

//验证学院是否为空
$('input[name="xueyuan"]').blur(function(){
    if($(this).val()=="" || $(this).val().search(/^([\u4e00-\u9fa5]){1,20}$/)==-1){
        $("#xueyuanId").html("请输入正确的学院");
        ok3 = false;
     }else{
    	 $("#xueyuanId").html("");
    	 ok3 = true;
     }
});

//验证专业是否为空
$('input[name="zhuanye"]').blur(function(){
    if($(this).val()=="" || $(this).val().search(/^([\u4e00-\u9fa5]){1,20}$/)==-1){
        $("#zhuanyeId").html("请输入正确的专业");
        ok4 = false;
     }else{
    	 $("#zhuanyeId").html("");
    	 ok4 = true;
     }
})

//验证QQ号
$('input[name="qq"]').blur(function(){
    if( $(this).val() == "" || $(this).val().search(/^\d{5,11}$/)==-1){
        $("#qqId").html("请输入正确的QQ号");
        ok5 = false;
     }else{
    	 $("#qqId").html("");
    	 ok5 = true;
     }
})

//验证学号
$('input[name="xuehao"]').blur(function(){
    if($(this).val().search(/^201(5|6|7|8)\d{6}$/)==-1){
        $("#xuehaoId").html("请输入正确的学号");     
        ok2 = false;
    }else{
        $.ajax({
            url:"hedui",
            data:{"xuehao":$(this).val()},
            dataType:"json",
            type:"post",
            success:function(msg){
                if(msg){
                    $("#xuehaoId").html("该学号已经报名");
                    ok2 = false;
                }else{
                	$("#xuehaoId").html("");
                	ok2 = true;
                }
            }
        });
    }

});

$("#submit").click(function(){
    if(ok1 && ok2 && ok3 && ok4 && ok5 && ok6){
    	$("#form1").submit();
    }else{
        alert("报名失败，请确认已正确填写所有内容");
        
        return false;
    }
});

$('#qq').popover({
    trigger : 'click',//鼠标以上时触发弹出提示框
    html:true,//开启html 为true的话，data-content里就能放html代码了
    content:"<img src='welcome/img/qq.jpg'>",
});

});